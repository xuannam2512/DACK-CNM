package com.nhom19.laptopapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaptopapiApplication.class, args);
	}

}

